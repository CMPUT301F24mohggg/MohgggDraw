package com.example.mohgggdraw;

/***
 * mainly for testing purpose
 * user that carries important info about itself
 * ***/

public class User {
    //placeholder
    private String email = "asdfssasdf";
    private String Uid;

    public String getUid() {
        return Uid;
    }

    public void setUid(String uid) {
        Uid = uid;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {


        return email;
    }
}

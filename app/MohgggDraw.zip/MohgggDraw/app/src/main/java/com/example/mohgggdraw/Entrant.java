package com.example.mohgggdraw;

public class Entrant {
}

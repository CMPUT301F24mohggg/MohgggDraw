package com.example.mohgggdraw;

import android.app.Activity;

public class WaitlistEntrantContentDeleteFragment extends Activity {
}

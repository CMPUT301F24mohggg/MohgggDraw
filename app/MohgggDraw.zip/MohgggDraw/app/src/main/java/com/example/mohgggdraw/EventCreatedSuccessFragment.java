package com.example.mohgggdraw;

import androidx.fragment.app.Fragment;

public class EventCreatedSuccessFragment extends Fragment {
}

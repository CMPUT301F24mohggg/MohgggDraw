package com.example.mohgggdraw;

import com.journeyapps.barcodescanner.CaptureActivity;


/**
 * Custom Capture Activity for barcode scanning.
 * Extends the default CaptureActivity to allow customization
 */
public class CaptureAct extends CaptureActivity {
}
